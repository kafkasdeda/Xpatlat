import filtersConfig from "../data/filters.json";
import useFilters from "../hooks/useFilters";
import FilterPanel from "../components/FilterPanel";
import ResultsPanel from "../components/ResultsPanel";

const getDefaultFilters = () =>
  filtersConfig.reduce((acc, f) => {
    acc[f.key] = f.default || "";
    return acc;
  }, {});

export default function SearchPage() {
  const { filters, updateFilter } = useFilters(getDefaultFilters());

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">
      <FilterPanel filters={filters} onUpdate={updateFilter} />
      <div className="col-span-2">
        <ResultsPanel filters={filters} />
      </div>
    </div>
  );
}
