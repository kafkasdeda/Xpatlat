import React from "react";

export default function FilterPanel({ filters, onUpdate }) {
  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8 space-y-6 border border-gray-200">
      <h2 className="text-2xl font-semibold text-gray-800 text-center">
        İçerik Filtresi
      </h2>

      {/* Text Search */}
      <div>
        <label className="block text-gray-700 font-medium mb-2">
          İçerik Ara
        </label>
        <input
          type="text"
          value={filters.textSearch}
          onChange={(e) => onUpdate("textSearch", e.target.value)}
          placeholder="#mizah, caps, gündem"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-800"
        />
        <div className="text-xs text-gray-500 mt-2 space-y-1">
          <p><code>#mizah</code>: Belirli bir hashtag</p>
          <p><code>"tam eşleşme"</code>: Tırnak içinde tam arama</p>
          <p><code>caps OR thread</code>: Veya koşullu arama</p>
          <p><code>-reklam</code>: "reklam" kelimesini dışlar</p>
        </div>
      </div>

      {/* Likes Slider */}
      <div>
        <label className="block text-gray-700 font-medium mb-2">
          En Az Beğeni: <span className="text-blue-600 font-bold">{filters.likesMin}</span>
        </label>
        <input
          type="range"
          min="0"
          max="1000"
          step="10"
          value={filters.likesMin}
          onChange={(e) => onUpdate("likesMin", parseInt(e.target.value))}
          className="w-full accent-blue-500"
        />
      </div>

      {/* Lang Select */}
      <div className="flex items-center gap-4">
        <label className="text-gray-700 font-medium">Dil</label>
        <select
          value={filters.lang}
          onChange={(e) => onUpdate("lang", e.target.value)}
          className="border border-gray-300 rounded-md px-3 py-1 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="tr">Türkçe</option>
          <option value="en">English</option>
        </select>
      </div>

      {/* Media Checkbox */}
      <div className="flex items-center space-x-3">
        <input
          type="checkbox"
          checked={filters.media}
          onChange={(e) => onUpdate("media", e.target.checked)}
          className="accent-blue-600 w-5 h-5"
        />
        <label className="text-gray-700 font-medium">Görsel İçeriyor</label>
      </div>

      {/* Results Preview */}
      <div className="pt-4 border-t">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Sonuçlar</h3>
        <pre className="bg-gray-100 p-4 rounded-lg text-sm text-gray-700 overflow-x-auto">
          {JSON.stringify(filters, null, 2)}
        </pre>
      </div>
    </div>
  );
}
