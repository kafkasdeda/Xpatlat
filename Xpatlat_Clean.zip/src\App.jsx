import SearchPage from "./pages/SearchPage";

export default function App() {
  return <SearchPage />;
}
