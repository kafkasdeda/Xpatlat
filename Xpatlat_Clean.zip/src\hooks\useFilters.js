import { useState } from "react";

export default function useFilters(defaultFilters) {
  const [filters, setFilters] = useState(defaultFilters);

  const updateFilter = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => setFilters(defaultFilters);

  return { filters, updateFilter, resetFilters };
}
