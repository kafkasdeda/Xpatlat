export default function ResultsPanel({ filters }) {
  return (
    <div className="bg-white p-4 shadow rounded">
      <h2 className="text-xl font-semibold mb-4">Sonuçlar</h2>
      <pre className="text-xs bg-gray-100 p-2 rounded">{JSON.stringify(filters, null, 2)}</pre>
    </div>
  );
}
